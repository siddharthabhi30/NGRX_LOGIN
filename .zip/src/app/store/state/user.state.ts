import { IUser } from "../models/user.model";

export interface IUserState{
    user:IUser;
    loggedIn:boolean;
    error:Error;
}
export const initialUserState:IUserState={
    user:null,
    loggedIn:false,
    error:undefined

}

