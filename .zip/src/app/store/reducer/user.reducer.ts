import { EUserActions, UserActions } from "../action/user.action";
import { initialUserState, IUserState } from "../state/user.state";

export const userReducer=(
    state=initialUserState,
    action:UserActions):IUserState=>{
        switch(action.type){

            case EUserActions.FIND_USER:
                console.log("at find user")
                return{
                    ...state
                }
            


            case EUserActions.USER_FAILURE:
                return {
                    ...state,
                    error:action.payload
                }
            case EUserActions.USER_SUCCESS:
                return {
                    ...state,
                    error:undefined,
                    loggedIn:true
                }

            default:
               
                return state;
                   
                
        }
    }

