export interface IUser{
    name:string;
    id:string;
}

