import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { GetUser } from './store/action/user.action';
import { selectError, selectState } from './store/selector/user.selector';
import { IAppState } from './store/state/app.state';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'login';
  constructor(private _store: Store<IAppState>) {}

  name:string;
  id:string;
  loggedIn$: Observable<Boolean>;
  error$: Observable<Error>

  ngOnInit() {
    this.error$=this._store.pipe(select(selectError));
    this.loggedIn$=this._store.pipe(select(selectState))
  }

  onLogin(){
    console.log(this.name,this.id)
    this._store.dispatch(new GetUser({id:this.id,name:this.name}));
    
  }
}
