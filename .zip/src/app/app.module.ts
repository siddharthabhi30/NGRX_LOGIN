import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { appReducer } from './store/reducer/app.reducer';
import {UserEffects}  from './store/effects/user.effects'
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    StoreModule.forRoot(appReducer),
    HttpClientModule,
    BrowserModule,
    FormsModule,
    EffectsModule.forRoot([UserEffects])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
